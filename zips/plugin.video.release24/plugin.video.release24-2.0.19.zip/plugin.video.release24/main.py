# -*- coding: utf-8 -*-

from bs4 import BeautifulSoup
import os
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import urllib
from urlparse import parse_qsl

addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
path = addon.getAddonInfo('path')
cat_enabled = addon.getSetting('cat_enabled')
search_enabled = addon.getSetting('search_enabled')
other_context = addon.getSetting('other_context')
default_search = addon.getSetting('default_search')
custom_name = addon.getSetting('custom_name')
custom_addon = addon.getSetting('custom_addon')
custom_movies = addon.getSetting('custom_movies')
custom_tv = addon.getSetting('custom_tv')
other_custom = addon.getSetting('other_custom')
other_fanfilm = addon.getSetting('other_fanfilm')
other_incursion = addon.getSetting('other_incursion')
other_filmwebbooster = addon.getSetting('other_filmwebbooster')
_url = sys.argv[0]
_handle = int(sys.argv[1])
apiurl = 'http://release24.pl/'
imdbUrl = 'https://www.imdb.com/title/'
movies = 'filmy'
tv = 'seriale'
path = addon.getAddonInfo('path')
media = os.path.join(path, 'resources', 'media')
rel24ico = os.path.join(path, 'icon.png')
rel24land = os.path.join(path, 'fanart.jpg')
rel24next = os.path.join(media, 'next.png')
rel24back = os.path.join(media, 'back.png')
rel24search = os.path.join(media, 'search.png')
openmetabase = 'plugin://plugin.video.openmeta'
release24base = 'plugin://plugin.video.release24'
import control


def notSupported(type):
    xbmcgui.Dialog().notification(addonname, type + ' nie obsługiwane', xbmcgui.NOTIFICATION_INFO);


def searchItems(query):
    dialog = xbmcgui.Dialog()
    search = dialog.input('Wpisz szukaną frazę', type=xbmcgui.INPUT_ALPHANUM, defaultt=query)
    getEntries(0, None, None, search)


def createLink(page, cat, subcat, search):
    url = apiurl
    if search is not None:
        url += 'szukacz/' + search + '//'
    if cat is not None:
        url += cat + '/'
    if subcat is not None:
        url += subcat + '/'
    url += str(page)
    # print('createLink: ' + url)
    return url


def appLinkAction(page, cat, subcat, search, action):
    url = _url + '?action=' + action + '&page=' + str(page)
    if cat is not None:
        url += '&cat=' + cat
    if subcat is not None:
        url += '&subcat=' + subcat
    if search is not None:
        url += '&search=' + search.replace(' ', '+')
    # print('appLink: ' + url)
    return url


def appLinkSearch(page, cat, subcat, search):
    return appLinkAction(page, cat, subcat, search, 'nextPage')


def appLink(page, cat, subcat):
    return appLinkAction(page, cat, subcat, None, 'nextPage')


def dftListItem(label):
    item = xbmcgui.ListItem(label=label)
    item.setArt({'thumb': rel24ico, 'fanart': rel24land})
    return item


def addMovieSubCat(listing):
    listing.append((appLink(0, movies, 'PL'), catListItem(label='PL'), True))
    listing.append((appLink(0, movies, 'BDRIP'), catListItem(label='BDRIP'), True))
    listing.append((appLink(0, movies, 'DVDRIP'), catListItem(label='DVDRIP'), True))
    listing.append((appLink(0, movies, 'WEB-DL'), catListItem(label='WEB-DL'), True))


def catListItem(label):
    lItem = xbmcgui.ListItem(label=label)
    lItem.setArt({'thumb': rel24ico, 'fanart': rel24land})
    return lItem


def addTvSubCat(listing):
    listing.append((appLink(0, tv, 'Akcja'), catListItem(label='Akcja'), True))
    listing.append((appLink(0, tv, 'Dramat'), catListItem(label='Dramat'), True))
    listing.append((appLink(0, tv, 'Komedia'), catListItem(label='Komedia'), True))
    listing.append((appLink(0, tv, 'Kryminał'), catListItem(label='Kryminał'), True))
    listing.append((appLink(0, tv, 'Przygodowy'), catListItem(label='Przygodowy'), True))
    listing.append((appLink(0, tv, 'Sci-Fi'), catListItem(label='Sci-Fi'), True))
    listing.append((appLink(0, tv, 'Fantasy'), catListItem(label='Fantasy'), True))
    listing.append((appLink(0, tv, 'Horror'), catListItem(label='Horror'), True))
    listing.append((appLink(0, tv, 'Thriller'), catListItem(label='Thriller'), True))
    listing.append((appLink(0, tv, 'Animowany'), catListItem(label='Animowany'), True))
    listing.append((appLink(0, tv, 'Dokumentalny'), catListItem(label='Dokumentalny'), True))


def addCategories(listing):
    listing.append((appLink(0, movies, None), dftListItem('Filmy >>'), True))
    listing.append((appLink(0, tv, None), dftListItem('Seriale >>'), True))


def addSearch(listing):
    if 'true' in search_enabled:
        searchButton = xbmcgui.ListItem(label='Szukaj')
        searchButton.setArt({'thumb': rel24search, 'fanart': rel24land})
        listing.append((appLinkAction(0, None, None, None, 'search'), searchButton, True))


def addCatSubcat(cat, subcat, listing, page, search):
    if 'true' in cat_enabled:
        if cat is None and subcat is None and page in '0' and search is None:
            addSearch(listing)
            addCategories(listing)
        elif cat is not None and subcat is None and page in '0':
            if movies in cat:
                addMovieSubCat(listing)
            elif tv in cat:
                addTvSubCat(listing)


def addBackButton(cat, subcat, listing, page):
    if page is not '0':
        backButton = xbmcgui.ListItem(label='Wróć do początku')
        backButton.setArt({'icon': rel24back, 'fanart': rel24land})  # , 'thumb': rel24ico
        if cat is None and subcat is None:
            listing.append((appLink(0, None, None), backButton, True))
        elif cat is not None and subcat is None:
            listing.append((appLink(0, None, None), backButton, True))
        elif cat is not None and subcat is not None:
            listing.append((appLink(0, cat, None), backButton, True))


def getSearchUrl(type, searchterm, target):
    url = 'plugin://plugin.video.' + target + '/?name="' + searchterm + '"&action='
    if 'seriale' in type:
        url += 'tvSearchterm'
    elif 'filmy' in type:
        url += 'movieSearchterm'
    else:
        url = appLinkAction(0, None, None, None, 'notSupported')
    return url


def videoArt(thumb):
    artVideo = {}
    artVideo['icon'] = thumb
    artVideo['thumb'] = thumb
    artVideo['poster'] = thumb
    artVideo['fanart'] = rel24land
    return artVideo


def get(url):
    r = requests.get(url)
    r.encoding = 'utf-8'
    return r.content


def getEntries(page, cat, subcat, search):
    listing = []
    addCatSubcat(cat, subcat, listing, str(page), search)
    nextPageNum = int(page) + 1
    soup = BeautifulSoup(get(createLink(page, cat, subcat, search)), 'html.parser')
    entries = soup.find_all('div', class_="wpis")
    #  pages = soup.find('div', id='pagin').find_all('p')
    for entry in entries:
        vidInfo = getVidInfo(entry)
        if vidInfo is not None:
            addListItem(listing, vidInfo)
    nextButton = xbmcgui.ListItem(label='[I]Następna strona ({0})[/I]'.format(str(nextPageNum + 1)))
    nextButton.setArt({'icon': rel24next, 'fanart': rel24land})  # , 'thumb': rel24ico
    listing.append((appLinkSearch(nextPageNum, cat, subcat, search), nextButton, True))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle, cacheToDisc=True)


def addListItem(listing, vidInfo):
    name = itemName(vidInfo)
    list_item = xbmcgui.ListItem(label=name)
    list_item.setArt(videoArt(vidInfo['thumb']))
    list_item.setInfo('video', createInfo(vidInfo))
    addCommands(list_item, vidInfo)
    url = ''
    if 'trailer' in vidInfo:
        url = vidInfo['trailer']
    url = openMetaUrl(vidInfo)
    control.logInfo(str(url))
    listing.append((url, list_item, False))  #True


def createInfo(vidInfo):
    info = {}
    if 'genre' in vidInfo:
        info['genre'] = vidInfo['genre']
    info['plotoutline'] = vidInfo['descr']
    if 'file' in vidInfo:
        info['plot'] = createDescr(vidInfo)
    if 'writer' in vidInfo:
        info['writer'] = vidInfo['writer']
    info['title'] = vidInfo['title']
    if 'season' in vidInfo:
        info['season'] = int(vidInfo['season'])
    if 'episode' in vidInfo:
        info['episode'] = int(vidInfo['episode'])
    if 'country' in vidInfo:
        info['country'] = vidInfo['country']
    if 'imdb' in vidInfo:
        info['imdbnumber'] = vidInfo['imdb']
    if 'genre' in vidInfo:
        info['genre'] = vidInfo['genre']
    if 'trailer' in vidInfo:
        info['path'] = vidInfo['trailer']
        info['trailer'] = vidInfo['trailer']
    if 'director' in vidInfo:
        info['director'] = vidInfo['director']
    if 'writer' in vidInfo:
        info['writer'] = vidInfo['writer']
    if 'duration' in vidInfo:
        try:
            info['duration'] = int(vidInfo['duration']) * 60
        except ValueError as e:
            print()
    if 'actors' in vidInfo:
        info['cast'] = vidInfo['actors']
    if 'credits' in vidInfo:
        info['credits'] = vidInfo['credits']
    if 'votes' in vidInfo:
        info['votes'] = vidInfo['votes']
    if 'rating' in vidInfo:
        info['rating'] = float(vidInfo['rating'])
    return info


def videoInfo(name, descr, genre, director, writer, trailer):
    vinfoVideo = {}
    vinfoVideo['genre'] = genre
    vinfoVideo['director'] = director
    vinfoVideo['writer'] = writer
    vinfoVideo['title'] = name
    vinfoVideo['plot'] = descr
    vinfoVideo['originaltitle'] = name
    if trailer is not None:
        vinfoVideo['trailer'] = trailer
    return vinfoVideo


def createDescr(vidInfo):
    descr = '[B][ OPIS ][/B]\n'
    descr += '[I]' + vidInfo['descr'] + '[/I]'
    if 'file' in vidInfo:
        descr += '\n\n[B][ INFORMACJE O PLIKU ][/B]\n'
        descr += vidInfo['file']
    return descr


def addCommands(list_item, vidInfo):
    commands = []
    commands.append(('Informacje', 'Action(Info)'))
    if 'trailer' in vidInfo:
        vidurl = 'RunPlugin({0})'.format(vidInfo['trailer'])
        commands.append(('Trailer', vidurl))
    if 'imdb' in vidInfo:
        url = '%s/movies/play/imdb/%s' % (openmetabase, vidInfo['imdb'])
        vidurl = 'RunPlugin(%s)' % url
        commands.append(('OpenMeta', vidurl))
    commands.append(('Wyszukaj podobne',
                         'Container.Refresh(' + appLinkAction(0, None, None, vidInfo['title'], 'search') + ')'))
    list_item.addContextMenuItems(commands)


def openMetaUrl(vidInfo):
    if vidInfo['type'] == 'series':
        return '%s/tv/play_by_name/%s/%s/%s/en' % (openmetabase, vidInfo['title'], vidInfo['season'], vidInfo['episode'])
    elif vidInfo['type'] == 'movie':
        if 'imdb' in vidInfo:
            if 'tt' in vidInfo['imdb']:
                return '%s/movies/play/imdb/%s' % (openmetabase, vidInfo['imdb'])
            else:
                return '%s/movies/play_by_name/%s/en' % (openmetabase, vidInfo['title'])
    else:
        print()


def itemName(vidInfo):
    name = '[B]' + vidInfo['title'] + '[/B]'
    if vidInfo['type'] == 'series':
        if 'season' in vidInfo and 'episode' in vidInfo:
            name += ' [B](' + vidInfo['season'] + 'x' + vidInfo['episode'] + ')[/B]'
    elif vidInfo['type'] == 'movie':
        print()
    else:
        print()
    if 'subtitle' in vidInfo:
        name += '[I]' + ' - "' + vidInfo['subtitle'] + '"[/I]'
    if 'addinfo' in vidInfo:
        name += '  [B][ ' + vidInfo['addinfo'] + ' ][/B]'

    name += ' - ' + vidInfo['relname']
    return name


def getThumbnail(vidInfo, entry):
    thumbrow = entry.find("img", {"class": "posterimg"})
    if thumbrow is not None:
        vidInfo['thumb'] = apiurl + thumbrow.get('src')


def additionalInfo(vidInfo, entry):
    additionalicon = entry.find('div', class_='additionalicon')
    if additionalicon is not None:
        img = additionalicon.find('img')
        if img is not None:
            vidInfo['addinfo'] = img.get('alt')


def getVidInfo(entry):
    vidInfo = {}
    additionalInfo(vidInfo, entry)
    setContentType(vidInfo, entry)
    if vidInfo['type'] is None:
        return None
    getThumbnail(vidInfo, entry)
    rows1 = entry.find_all('div', class_='row1')
    rows0 = entry.find_all('div', class_='row0')
    firstInfo = rows1[0].find_all('p', class_='i')
    for info1 in firstInfo:
        infoName = info1.find('span', class_='i').get_text()[:12].replace('.', ' ')
        infoValue = info1.find('span', class_='vi').get_text()
        addFirtsInfo(vidInfo, infoName, infoValue)
    descr = entry.find('div', class_='opis').find('p').get_text().replace('OPIS: ', '')
    vidInfo['descr'] = descr
    imdbInfo(vidInfo, rows1[1])
    ytlink(vidInfo, rows0[1])
    getFileInf(vidInfo, rows1[2])
    return vidInfo


def getFileInf(vidInfo, moreInfo):
    fileInfos = moreInfo.find_all('p', class_='i2')
    fileTxt = ''
    for fileInfo in fileInfos:
        infoName = fileInfo.find('span', class_='i2').get_text()[:12].replace('.', '')
        infoValue = fileInfo.find('span', class_='vi2').get_text().replace(': ', '', 1)
        if 'Sample' in infoName or 'Screeny' in infoName:
            print()
        else:
            fileTxt += '  [B]' + infoName + ':[/B]\n'
            values = infoValue.split(';')
            for value in values:
                fileTxt += '    [I]' + value + '[/I]\n'
    vidInfo['file'] = fileTxt


def setContentType(vidInfo, entry):
    type = None
    header = entry.find('h1')
    relType = header.get('class')
    if relType is not None:
        if 'filmy' in relType:
            type = 'movie'
        elif 'seriale' in relType:
            type = 'series'
        else:
            type = 'other'
    vidInfo['type'] = type
    vidInfo['relname'] = header.find('a').get_text()


def imdbInfo(vidInfo, moreInfo):
    links = moreInfo.find_all('a')
    for a in links:
        href = a.get('href')
        if imdbUrl in href:
            vidInfo['imdb'] = href.replace(imdbUrl, '').replace('/', '').split('?')[0]


def ytlink(vidInfo, moreInfo):
    yturl = moreInfo.find('a', target='_blank')
    try:
        if yturl is not None:
            yturl = yturl.get('href')
            trailerurl = None
            if 'youtu.be' in yturl:
                trailerurl = yturl.replace('https://youtu.be/', '')
            elif 'youtube.com' in yturl:
                trailerurl = yturl.split('?')[1].replace('v=', '')
            if trailerurl is not None:
                vidInfo['trailer'] = 'plugin://plugin.video.youtube/play/?video_id={0}'.format(trailerurl)
    except Exception as e:
        print()



def addFirtsInfo(vidInfo, name, value):
    if 'Tytu' in name:
        value = value.replace(': ', '', 1)
        if '/' in value:
            splName = value.split('/')
            vidInfo['title'] = splName[0]
            vidInfo['subtitle'] = splName[1]
        else:
            vidInfo['title'] = value

    elif 'Gatunek' in name:
        vidInfo['genre'] = value.replace(': ', '')
    elif 'Aktorzy' in name:
        actSpl = value.replace(': ', '').split(',')
        actors = []
        for act in actSpl:
            actors.append(act)
        vidInfo['actors'] = actors
    elif 'yseria' in name:
        vidInfo['director'] = value
    elif 'Scenariusz' in name:
        vidInfo['writer'] = value
    elif 'Sezon' in name:
        vidInfo['season'] = value.replace(': ', '')
    elif 'Epizod' in name:
        vidInfo['episode'] = value.replace(': ', '').split('-')[0]
    elif 'Produkcja' in name:
        countrySpl = value.replace(': ', '').split(',')
        countrys = []
        for country in countrySpl:
            countrys.append(country)
        vidInfo['country'] = countrys
    elif 'Czas trwania' in name:
        if 'x' in value:
            vidInfo['duration'] = value.replace(': ', '').replace('~', '').split(' x ')[1].split('-')[0].split(' ')[0]
        else:
            vidInfo['duration'] = value.replace(': ', '').split(' ')[0]
    elif 'rcy.' in name:
        credSpl = value.replace(': ', '').split(',')
        credits = []
        for credit in credSpl:
            credits.append(credit)
        vidInfo['credits'] = credits
    elif 'Ocena' in name:
        if 'IMDB' in value:
            rateVote = value.replace(': ', '').split(',')[0].replace('IMDB - ', '').replace('(', '').replace(')', '').split(' ')
            vidInfo['rating'] = rateVote[0].split('/')[0]
            vidInfo['votes'] = rateVote[1]


def updatePlayers():
    import updater
    updater.update_players('http://zips.ovh/ff.zip')


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action = 'nextPage'
    cat = None
    subcat = None
    page = 0
    search = None
    id = None
    target = None
    if params:
        if 'action' in params:
            action = params['action']
        if 'page' in params:
            print('PageIn: ' + str(params['page']))
            page = params['page']
        if 'cat' in params:
            cat = params['cat']
        if 'subcat' in params:
            subcat = params['subcat']
        if 'search' in params:
            search = params['search']
        if 'id' in params:
            id = params['id']
        if 'target' in params:
            target = params['target']
    if 'nextPage' in action:
        getEntries(page, cat, subcat, search)
    elif 'search' in action:
        searchItems(search)
    elif 'notSupported' in action:
        notSupported(cat)
    elif 'updatePlayers' in action:
        updatePlayers()
    elif 'playTrailer' in action:
        print(action + ' : ' + target + ' : ' + id)


if __name__ == '__main__':
    router(sys.argv[2][1:])
