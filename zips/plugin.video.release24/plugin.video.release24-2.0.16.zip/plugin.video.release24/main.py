# -*- coding: utf-8 -*-

from bs4 import BeautifulSoup
import os
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import urllib
from urlparse import parse_qsl

addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
path = addon.getAddonInfo('path')
cat_enabled = addon.getSetting('cat_enabled')
search_enabled = addon.getSetting('search_enabled')
other_context = addon.getSetting('other_context')
default_search = addon.getSetting('default_search')
custom_name = addon.getSetting('custom_name')
custom_addon = addon.getSetting('custom_addon')
custom_movies = addon.getSetting('custom_movies')
custom_tv = addon.getSetting('custom_tv')
other_custom = addon.getSetting('other_custom')
other_fanfilm = addon.getSetting('other_fanfilm')
other_incursion = addon.getSetting('other_incursion')
other_filmwebbooster = addon.getSetting('other_filmwebbooster')
_url = sys.argv[0]
_handle = int(sys.argv[1])
apiurl = 'http://release24.pl/'
imdbUrl = 'https://www.imdb.com/title/'
movies = 'filmy'
tv = 'seriale'
media = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
rel24ico = os.path.join(media, 'icon7.png')
rel24land = os.path.join(media, 'fanart3.jpg')
rel24next = os.path.join(media, 'next.png')
rel24back = os.path.join(media, 'back.png')
rel24search = os.path.join(media, 'search.png')
targets = {}
targets['1'] = {'name': custom_name,
                'addon': custom_addon,
                'movie_url': custom_movies,
                'tv_url': custom_tv}
targets['2'] = {'name': 'FanFilm',
                'addon': 'plugin.video.fanfilm',
                'movie_url': 'name="QUERY"&action=movieSearchterm',
                'tv_url': 'name="QUERY"&action=tvSearchterm'}
targets['3'] = {'name': 'Incursion',
                'addon': 'plugin.video.incursion',
                'movie_url': 'name="QUERY"&action=movieSearchterm',
                'tv_url': 'name="QUERY"&action=tvSearchterm'}
targets['4'] = {'name': 'FilmwebBooster',
                'addon': 'plugin.video.filmbooster',
                'movie_url': 'ex_link=QUERY&mode=SzukajNowe&page=1&foldername=QUERY&minfo={}',
                'tv_url': 'ex_link=QUERY&mode=SzukajNowe&page=1&foldername=QUERY&minfo={}'}


def notSupported(type):
    xbmcgui.Dialog().notification(addonname, type + ' nie obsługiwane', xbmcgui.NOTIFICATION_INFO);


def searchItems(query):
    dialog = xbmcgui.Dialog()
    search = dialog.input('Wpisz szukaną frazę', type=xbmcgui.INPUT_ALPHANUM, defaultt=query)
    getEntries(0, None, None, search)


def createLink(page, cat, subcat, search):
    url = apiurl
    if search is not None:
        url += 'szukacz/' + search + '//'
    if cat is not None:
        url += cat + '/'
    if subcat is not None:
        url += subcat + '/'
    url += str(page)
    # print('createLink: ' + url)
    return url


def appLinkAction(page, cat, subcat, search, action):
    url = _url + '?action=' + action + '&page=' + str(page)
    if cat is not None:
        url += '&cat=' + cat
    if subcat is not None:
        url += '&subcat=' + subcat
    if search is not None:
        url += '&search=' + search.replace(' ', '+')
    # print('appLink: ' + url)
    return url


def appLinkSearch(page, cat, subcat, search):
    return appLinkAction(page, cat, subcat, search, 'nextPage')


def appLink(page, cat, subcat):
    return appLinkAction(page, cat, subcat, None, 'nextPage')


def dftListItem(label):
    item = xbmcgui.ListItem(label=label)
    item.setArt({'thumb': rel24ico, 'fanart': rel24land})
    return item


def addMovieSubCat(listing):
    listing.append((appLink(0, movies, 'PL'), catListItem(label='PL'), True))
    listing.append((appLink(0, movies, 'BDRIP'), catListItem(label='BDRIP'), True))
    listing.append((appLink(0, movies, 'DVDRIP'), catListItem(label='DVDRIP'), True))
    listing.append((appLink(0, movies, 'WEB-DL'), catListItem(label='WEB-DL'), True))


def catListItem(label):
    lItem = xbmcgui.ListItem(label=label)
    lItem.setArt({'thumb': rel24ico})
    return lItem


def addTvSubCat(listing):
    listing.append((appLink(0, tv, 'Akcja'), catListItem(label='Akcja'), True))
    listing.append((appLink(0, tv, 'Dramat'), catListItem(label='Dramat'), True))
    listing.append((appLink(0, tv, 'Komedia'), catListItem(label='Komedia'), True))
    listing.append((appLink(0, tv, 'Kryminał'), catListItem(label='Kryminał'), True))
    listing.append((appLink(0, tv, 'Przygodowy'), catListItem(label='Przygodowy'), True))
    listing.append((appLink(0, tv, 'Sci-Fi'), catListItem(label='Sci-Fi'), True))
    listing.append((appLink(0, tv, 'Fantasy'), catListItem(label='Fantasy'), True))
    listing.append((appLink(0, tv, 'Horror'), catListItem(label='Horror'), True))
    listing.append((appLink(0, tv, 'Thriller'), catListItem(label='Thriller'), True))
    listing.append((appLink(0, tv, 'Animowany'), catListItem(label='Animowany'), True))
    listing.append((appLink(0, tv, 'Dokumentalny'), catListItem(label='Dokumentalny'), True))


def addCategories(listing):
    listing.append((appLink(0, movies, None), dftListItem('Filmy >>'), True))
    listing.append((appLink(0, tv, None), dftListItem('Seriale >>'), True))


def addSearch(listing):
    if 'true' in search_enabled:
        searchButton = xbmcgui.ListItem(label='Szukaj')
        searchButton.setArt({'thumb': rel24search, 'fanart': rel24land})
        listing.append((appLinkAction(0, None, None, None, 'search'), searchButton, True))


def addCatSubcat(cat, subcat, listing, page, search):
    if 'true' in cat_enabled:
        if cat is None and subcat is None and page in '0' and search is None:
            addSearch(listing)
            addCategories(listing)
        elif cat is not None and subcat is None and page in '0':
            if movies in cat:
                addMovieSubCat(listing)
            elif tv in cat:
                addTvSubCat(listing)


def addBackButton(cat, subcat, listing, page):
    if page is not '0':
        backButton = xbmcgui.ListItem(label='Wróć do początku')
        backButton.setArt({'icon': rel24back, 'fanart': rel24land})  # , 'thumb': rel24ico
        if cat is None and subcat is None:
            listing.append((appLink(0, None, None), backButton, True))
        elif cat is not None and subcat is None:
            listing.append((appLink(0, None, None), backButton, True))
        elif cat is not None and subcat is not None:
            listing.append((appLink(0, cat, None), backButton, True))


def getSearchUrl(type, searchterm, target):
    url = 'plugin://plugin.video.' + target + '/?name="' + searchterm + '"&action='
    if 'seriale' in type:
        url += 'tvSearchterm'
    elif 'filmy' in type:
        url += 'movieSearchterm'
    else:
        url = appLinkAction(0, None, None, None, 'notSupported')
    return url


def getUrlSearch(type, searchterm, target):
    url = 'plugin://'
    if target != '0':
        url += targets[target]['addon']
        url += '/?'
        if 'seriale' in type:
            url += targets[target]['tv_url'].replace('QUERY', searchterm)
        elif 'filmy' in type:
            url += targets[target]['movie_url'].replace('QUERY', searchterm)
    #  xbmc.log(msg='Rel24: ' + url, level=xbmc.LOGERROR)
    return url


def videoArt(thumb):
    artVideo = {}
    artVideo['icon'] = thumb
    artVideo['thumb'] = thumb
    artVideo['poster'] = thumb
    artVideo['fanart'] = rel24land
    return artVideo


def checkTargetAddon():
    if default_search != '0':
        target = targets[default_search]
        try:
            xbmcaddon.Addon(id=target['addon'])
        except RuntimeError:
            xbmcgui.Dialog().notification(addonname, 'Brak dodatku: ' + target['name'], xbmcgui.NOTIFICATION_ERROR)
            addon.openSettings()


def get(url):
    r = requests.get(url)
    r.encoding = 'utf-8'
    return r.content


def getEntries(page, cat, subcat, search):
    listing = []
    addCatSubcat(cat, subcat, listing, str(page), search)
    nextPageNum = int(page) + 1
    soup = BeautifulSoup(get(createLink(page, cat, subcat, search)), 'html.parser')
    entries = soup.find_all('div', class_="wpis")
    #  pages = soup.find('div', id='pagin').find_all('p')
    for entry in entries:
        vidInfo = getVidInfo(entry)
        if vidInfo is not None:
            addListItem(listing, vidInfo)
    nextButton = xbmcgui.ListItem(label='[I]Następna strona ({0})[/I]'.format(str(nextPageNum + 1)))
    nextButton.setArt({'icon': rel24next, 'fanart': rel24land})  # , 'thumb': rel24ico
    listing.append((appLinkSearch(nextPageNum, cat, subcat, search), nextButton, True))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle, cacheToDisc=True)


def addListItem(listing, vidInfo):
    name = itemName(vidInfo)
    list_item = xbmcgui.ListItem(label=name)
    #  addActors(list_item, vidInfo)
    list_item.setArt(videoArt(vidInfo['thumb']))
    descr = createDescr(vidInfo)
    list_item.setInfo('video', createInfo(vidInfo))
    addCommands(list_item, vidInfo)
    url = ''
    if 'trailer' in vidInfo:
        url = vidInfo['trailer']
    listing.append((url, list_item, False))  #True


def createInfo(vidInfo):
    info = {}
    if 'genre' in vidInfo:
        info['genre'] = vidInfo['genre']
    info['plotoutline'] = vidInfo['descr']
    if 'file' in vidInfo:
        info['plot'] = createDescr(vidInfo)
    if 'writer' in vidInfo:
        info['writer'] = vidInfo['writer']
    info['title'] = vidInfo['title']
    if 'season' in vidInfo:
        info['season'] = int(vidInfo['season'])
    if 'episode' in vidInfo:
        info['episode'] = int(vidInfo['episode'])
    if 'country' in vidInfo:
        info['country'] = vidInfo['country']
    if 'imdb' in vidInfo:
        info['imdbnumber'] = vidInfo['imdb']
    if 'genre' in vidInfo:
        info['genre'] = vidInfo['genre']
    if 'trailer' in vidInfo:
        info['path'] = vidInfo['trailer']
        info['trailer'] = vidInfo['trailer']
    if 'director' in vidInfo:
        info['director'] = vidInfo['director']
    if 'writer' in vidInfo:
        info['writer'] = vidInfo['writer']
    if 'duration' in vidInfo:
        try:
            info['duration'] = int(vidInfo['duration']) * 60
        except ValueError as e:
            print()
    if 'actors' in vidInfo:
        info['cast'] = vidInfo['actors']
    if 'credits' in vidInfo:
        info['credits'] = vidInfo['credits']
    if 'votes' in vidInfo:
        info['votes'] = vidInfo['votes']
    if 'rating' in vidInfo:
        info['rating'] = float(vidInfo['rating'])
    return info


def videoInfo(name, descr, genre, director, writer, trailer):
    vinfoVideo = {}
    vinfoVideo['genre'] = genre
    vinfoVideo['director'] = director
    vinfoVideo['writer'] = writer
    vinfoVideo['title'] = name
    vinfoVideo['plot'] = descr
    vinfoVideo['originaltitle'] = name
    if trailer is not None:
        vinfoVideo['trailer'] = trailer
    return vinfoVideo


def createDescr(vidInfo):
    descr = vidInfo['descr']
    if 'file' in vidInfo:
        descr += '\n\nINFORMACJE O PLIKU:\n' + vidInfo['file']
    return descr


def addActors(list_item, vidInfo):
    if 'actors' in vidInfo:
        actorslist = []
        for actor in vidInfo['actors']:
            actorslist.append({'name': actor})
        list_item.setCast(actorslist)


def addCommands(list_item, vidInfo):
    commands = []
    commands.append(('Informacje', 'Action(Info)'))
    if 'trailer' in vidInfo:
        vidurl = 'RunPlugin({0})'.format(vidInfo['trailer'])
        commands.append(('Trailer', vidurl))
        commands.append(('Wyszukaj podobne',
                         'Container.Refresh(' + appLinkAction(0, None, None, vidInfo['title'], 'search') + ')'))
    list_item.addContextMenuItems(commands)


def itemName(vidInfo):
    name = '[B]' + vidInfo['title'] + '[/B]'
    if vidInfo['type'] == 'series':
        if 'season' in vidInfo and 'episode' in vidInfo:
            name += ' [B](' + vidInfo['season'] + 'x' + vidInfo['episode'] + ')[/B]'
    elif vidInfo['type'] == 'movie':
        print()
    else:
        print()
    if 'subtitle' in vidInfo:
        name += '[I]' + ' - "' + vidInfo['subtitle'] + '"[/I]'
    if 'addinfo' in vidInfo:
        name += '  [B][ ' + vidInfo['addinfo'] + ' ][/B]'

    name += ' - ' + vidInfo['relname']
    return name


def getThumbnail(vidInfo, entry):
    thumbrow = entry.find("img", {"class": "posterimg"})
    if thumbrow is not None:
        vidInfo['thumb'] = apiurl + thumbrow.get('src')


def additionalInfo(vidInfo, entry):
    additionalicon = entry.find('div', class_='additionalicon')
    if additionalicon is not None:
        img = additionalicon.find('img')
        if img is not None:
            vidInfo['addinfo'] = img.get('alt')


def getVidInfo(entry):
    vidInfo = {}
    additionalInfo(vidInfo, entry)
    setContentType(vidInfo, entry)
    if vidInfo['type'] is None:
        return None
    getThumbnail(vidInfo, entry)
    rows1 = entry.find_all('div', class_='row1')
    rows0 = entry.find_all('div', class_='row0')
    firstInfo = rows1[0].find_all('p', class_='i')
    for info1 in firstInfo:
        infoName = info1.find('span', class_='i').get_text()[:12].replace('.', ' ')
        infoValue = info1.find('span', class_='vi').get_text()
        addFirtsInfo(vidInfo, infoName, infoValue)
    descr = entry.find('div', class_='opis').find('p').get_text().replace('OPIS: ', '')
    vidInfo['descr'] = descr
    imdbInfo(vidInfo, rows1[1])
    ytlink(vidInfo, rows0[1])
    getFileInf(vidInfo, rows1[2])
    return vidInfo


def getFileInf(vidInfo, moreInfo):
    fileInfos = moreInfo.find_all('p', class_='i2')
    fileTxt = ''
    for fileInfo in fileInfos:
        infoName = fileInfo.find('span', class_='i2').get_text()[:12].replace('.', '')
        infoValue = fileInfo.find('span', class_='vi2').get_text()
        if 'Sample' in infoName or 'Screeny' in infoName:
            print()
        else:
            fileTxt += infoName + infoValue + '\n'
    vidInfo['file'] = fileTxt


def setContentType(vidInfo, entry):
    type = None
    header = entry.find('h1')
    relType = header.get('class')
    if relType is not None:
        if 'filmy' in relType:
            type = 'movie'
        elif 'seriale' in relType:
            type = 'series'
        else:
            type = 'other'
    vidInfo['type'] = type
    vidInfo['relname'] = header.find('a').get_text()


def imdbInfo(vidInfo, moreInfo):
    links = moreInfo.find_all('a')
    for a in links:
        href = a.get('href')
        if imdbUrl in href:
            vidInfo['imdb'] = href.replace(imdbUrl, '').replace('/', '').split('?')[0]


def ytlink(vidInfo, moreInfo):
    yturl = moreInfo.find('a', target='_blank')
    if yturl is not None:
        yturl = yturl.get('href')
        trailerurl = None
        if 'youtu.be' in yturl:
            trailerurl = yturl.replace('https://youtu.be/', '')
        elif 'youtube.com' in yturl:
            trailerurl = yturl.split('?')[1].replace('v=', '')
        if trailerurl is not None:
            vidInfo['trailer'] = 'plugin://plugin.video.youtube/play/?video_id={0}'.format(trailerurl)


def addFirtsInfo(vidInfo, name, value):
    if 'Tytu' in name:
        value = value.replace(': ', '', 1)
        if '/' in value:
            splName = value.split('/')
            vidInfo['title'] = splName[0]
            vidInfo['subtitle'] = splName[1]
        else:
            vidInfo['title'] = value

    elif 'Gatunek' in name:
        vidInfo['genre'] = value.replace(': ', '')
    elif 'Aktorzy' in name:
        actSpl = value.replace(': ', '').split(',')
        actors = []
        for act in actSpl:
            actors.append(act)
        vidInfo['actors'] = actors
    elif 'yseria' in name:
        vidInfo['director'] = value
    elif 'Scenariusz' in name:
        vidInfo['writer'] = value
    elif 'Sezon' in name:
        vidInfo['season'] = value.replace(': ', '')
    elif 'Epizod' in name:
        vidInfo['episode'] = value.replace(': ', '').split('-')[0]
    elif 'Produkcja' in name:
        countrySpl = value.replace(': ', '').split(',')
        countrys = []
        for country in countrySpl:
            countrys.append(country)
        vidInfo['country'] = countrys
    elif 'Czas trwania' in name:
        if 'x' in value:
            vidInfo['duration'] = value.replace(': ', '').replace('~', '').split(' x ')[1].split('-')[0].split(' ')[0]
        else:
            vidInfo['duration'] = value.replace(': ', '').split(' ')[0]
    elif 'rcy.' in name:
        credSpl = value.replace(': ', '').split(',')
        credits = []
        for credit in credSpl:
            credits.append(credit)
        vidInfo['credits'] = credits
    elif 'Ocena' in name:
        if 'IMDB' in value:
            rateVote = value.replace(': ', '').split(',')[0].replace('IMDB - ', '').replace('(', '').replace(')', '').split(' ')
            vidInfo['rating'] = rateVote[0].split('/')[0]
            vidInfo['votes'] = rateVote[1]


def getEntries2(page, cat, subcat, search):
    # print('handle: ' + str(_handle) + ' ' + str(_url))
    checkTargetAddon()
    r = requests.get(createLink(page, cat, subcat, search))
    r.encoding = 'utf-8'
    data = r.content
    soup = BeautifulSoup(data, 'html.parser')
    entries = soup.findAll("div", {"class": "wpis"})
    pages = soup.find('div', {'id': 'pagin'}).findAll('p')
    listing = []
    nextPageNum = int(page) + 1
    addCatSubcat(cat, subcat, listing, str(page), search)
    for entry in entries:
        additional = entry.find('div', {'class': 'additionalicon'})
        add = None
        commands = []
        header = entry.find("h1")
        type = header.get('class')
        if type is not None:
            relName = header.find('a').get_text()
            thumbrow = entry.find("img", {"class": "posterimg"})
            info = entry.find("td", {"class": "info"})
            thumb = None
            name = None
            genre = None
            searchterm = None
            actors = []
            director = None
            writer = None
            trailer = None
            if thumbrow is not None:
                thumb = apiurl + thumbrow.get('src')
            if additional is not None:
                add = additional.find('img').get('alt')
            if info is not None:
                vidinfo = info.find("div", {"class": "row1 first"})
                infos = vidinfo.findAll("p", {"class": "i"})
                # itemInfo = ''
                for inf in infos:
                    infn = inf.find("span", {"class": "i"}).get_text()
                    infv = inf.find("span", {"class": "vi"}).get_text().replace(': ', '', 1).split('/')[0]
                    # itemInfo += '[B]' + infn.replace('.', '') + ': [/B]' + infv + '\n'
                    if 'Tytu' in infn:
                        searchterm = infv.encode('utf-8').strip()
                        name = '[B]' + infv + '[/B]'
                        if add is not None:
                            name += ' (' + add + ')'
                    elif 'Gatunek' in infn:
                        genre = infv
                    elif 'Aktorzy' in infn:
                        relActors = infv.split(',')
                        for act in relActors:
                            actors.append({'name': act})
                    elif 'yseria' in infn:
                        director = infv
                    elif 'Scenariusz' in infn:
                        writer = infv.split(',')

                descrrow = info.findAll("div", {"class": "row0"})
                # '[B]Opis:[/B]' +
                descr = descrrow[0].find("p").get_text().replace('OPIS:', '') + '\n'
                # descr += itemInfo
                vidurlOpt = descrrow[1].find("a", {"target": "_blank"})
                if vidurlOpt is not None:
                    # vidid = 'G8kNjHEAsN0' #  TEST_ID
                    # trailer = vidurlOpt.get('href')
                    vidid = vidurlOpt.get('href').replace('https://youtu.be/', '')
                    vidurl = 'RunPlugin(plugin://plugin.video.youtube/play/?video_id=' + vidid + ')'
                    trailer = 'plugin://plugin.video.youtube/play/?video_id=%s' % vidid
                    commands.append(('Trailer', vidurl))
            name += ' - ' + relName
            list_item = xbmcgui.ListItem(label=name)
            list_item.setCast(actors)
            list_item.setArt(videoArt(thumb))
            list_item.setInfo('video', videoInfo(name, descr, genre, director, writer, trailer))
            # getUrlSearch(type, searchterm)
            # xbmc.log(msg='Rel25: ' + getSearchUrl(type, searchterm, 'fanfilm'), level=xbmc.LOGERROR)
            listing.append((getUrlSearch(type, searchterm, default_search), list_item, True))
            # listing.append((getSearchUrl(type, searchterm, 'fanfilm'), list_item, True))
            commands.append(('Informacje', 'Action(Info)'))
            if 'true' in other_context:
                # addContextSearch(commands, searchterm, type)
                commands.append(('TEST ->',
                                 'RunPlugin(plugin://plugin.video.fanfilm/?name="%s"&action=movieSearchterm)' % searchterm))
                print()
            commands.append(
                ('OpenMeta', 'RunPlugin(plugin://plugin.video.openmeta/search/edit/{0})'.format(searchterm)))
            commands.append(('Wyszukaj podobne',
                             'Container.Refresh(' + appLinkAction(0, None, None, searchterm, 'search') + ')'))
            testUrl = 'RunPlugin(plugin://plugin.video.fanfilm/?action=play&title={0}&imdb=tt8936646&year=2020&t=20200507065648965060&meta={})'
            commands.append(('TEST ->', testUrl))
            list_item.addContextMenuItems(commands)
    if len(pages) > 5:
        addBackButton(cat, subcat, listing, str(page))
        nextButton = xbmcgui.ListItem(label='[I]Następna strona[/I]')
        nextButton.setArt({'icon': rel24next, 'fanart': rel24land})  # , 'thumb': rel24ico
        listing.append((appLinkSearch(nextPageNum, cat, subcat, search), nextButton, True))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle, cacheToDisc=False)
    # xbmcplugin.endOfDirectory(_handle)


def addContextSearch(commands, searchterm, type):
    if default_search != '1' and other_custom == 'true' and custom_name != '':
        addContextSearchEntry(commands, targets['1']['name'], searchterm, type, '1')
    if default_search != '2' and other_fanfilm == 'true':
        addContextSearchEntry(commands, targets['2']['name'], searchterm, type, '2')
    if default_search != '3' and other_incursion == 'true':
        addContextSearchEntry(commands, targets['3']['name'], searchterm, type, '3')
    if default_search != '4' and other_filmwebbooster == 'true':
        addContextSearchEntry(commands, targets['4']['name'], searchterm, type, '4')


def addContextSearchEntry(commands, name, searchterm, type, target):
    url = 'XBMC.RunPlugin(' + getUrlSearch(type, searchterm, target) + ')'
    # url = 'RunPlugin(%s)' % getUrlSearch(type, searchterm, target)
    #  xbmc.log(msg='Ctx24: ' + url, level=xbmc.LOGERROR)
    commands.append((name + ' >>', url))


def updatePlayers():
    import updater
    updater.update_players('http://zips.ovh/ff.zip')


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action = 'nextPage'
    cat = None
    subcat = None
    page = 0
    search = None
    if params:
        if 'action' in params:
            action = params['action']
        if 'page' in params:
            print('PageIn: ' + str(params['page']))
            page = params['page']
        if 'cat' in params:
            cat = params['cat']
        if 'subcat' in params:
            subcat = params['subcat']
        if 'search' in params:
            search = params['search']
    if 'nextPage' in action:
        getEntries(page, cat, subcat, search)
    elif 'search' in action:
        searchItems(search)
    elif 'notSupported' in action:
        notSupported(cat)
    elif 'updatePlayers' in action:
        updatePlayers()


if __name__ == '__main__':
    router(sys.argv[2][1:])
