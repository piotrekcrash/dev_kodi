# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui

addon = xbmcaddon.Addon()
profile = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
player_path = profile + 'Players'
addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')


def yesno(msg):
    decision = xbmcgui.Dialog().yesno(addonname, msg)
    return bool(decision)


def sendError(error):
    xbmcgui.Dialog().notification(addonname, error, xbmcgui.NOTIFICATION_ERROR)


def sendInfo(info):
    xbmcgui.Dialog().notification(addonname, info, icon=icon)


def logInfo(info):
    xbmc.log(msg=addonname + ' - ' + info, level=xbmc.LOGNOTICE)


def logError(error):
        xbmc.log(msg=addonname + ' - ' + error, level=xbmc.LOGERROR)
